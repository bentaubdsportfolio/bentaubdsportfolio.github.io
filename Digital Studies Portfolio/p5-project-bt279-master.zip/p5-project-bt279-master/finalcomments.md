# Interactivity
Extensive interaction here allowing you to not just color but to change the color. I also like that you included two means of interaction: keyboard and mouse.

# Code Quality
You did a lot with just a few lines of code. Part of that is what P5 enables you to do, but, even so, you kept it clean. More comments would have been good, however.

# Aesthetics
This was a fun little project that did what it needed to do and little more in the short time allotted for the project.
